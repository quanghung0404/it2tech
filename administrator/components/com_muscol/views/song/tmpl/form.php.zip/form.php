<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<div class="col100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Details' ); ?></legend>
		
		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="name">
					<?php echo JText::_( 'Song name' ); ?>:
				</label>
			</td>
			<td>
<input class="text_area" type="text" name="name" id="name" size="100" maxlength="250" value="<?php echo $this->song->name;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="name2">
					<?php echo JText::_( 'Disc Number' ); ?>:
				</label>
			</td>
			<td>
<input class="text_area" type="text" name="disc_num" id="disc_num" size="2" maxlength="4" value="<?php echo $this->song->disc_num;?>" />

			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="subtitle">
					<?php echo JText::_( 'Song Number' ); ?>:
				</label>
			</td>
			<td>
            <input class="text_area" type="text" name="num" id="num" size="2" maxlength="4" value="<?php echo $this->song->num;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="subtitle">
					<?php echo JText::_( 'Length' ); ?>:
				</label>
			</td>
			<td>
            <input class="text_area" type="text" name="hours" id="hours" size="2" maxlength="2" value="<?php echo $this->song->hours;?>" /> : <input class="text_area" type="text" name="minuts" id="minuts" size="2" maxlength="2" value="<?php echo $this->song->minuts;?>" /> : <input class="text_area" type="text" name="seconds" id="seconds" size="2" maxlength="2" value="<?php echo $this->song->seconds;?>" />
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="artist">
					<?php echo JText::_( 'Artist' ); ?>:
				</label>
			</td>
			<td><?php //print_r ($this->song); ?>
            <select name="artist_id" id="artist_id">
            <?php
			for ($i=0, $n=count( $this->artists );$i < $n; $i++)	{
			$row = &$this->artists[$i];
			$selected = ""; 
			if($row->id == $this->song->artist_id) $selected = "selected";
			else if(!$this->song->artist_id && $this->artist_from_album == $row->id ) $selected = "selected";
			
			?>
            <option <?php echo $selected;?> value="<?php echo $row->id;?>"><?php echo $row->artist_name;?></option>
            <?php } ?>
			</select>
			</td>
		</tr>
        
        <tr>
			<td width="100" align="right" class="key">
				<label for="genre">
					<?php echo JText::_( 'Genre' ); ?>:
				</label>
			</td>
       		 <td>
			<select name="genre_id" id="genre_id">
			<?php echo $this->show_genre_tree($this->genres,0); ?>
            </select>
			</td>
          </tr>
        
        <tr>
			<td width="100" align="right" class="key">
				<label for="file">
					<?php echo JText::_( 'File' ); ?>:
				</label>
			</td>
			<td>
<input class="text_area" type="text" name="filename" id="filename" size="32" maxlength="250" value="<?php echo $this->song->filename;?>" />
<input type="file" name="song_file" id="song_file"/>
		
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="lyrics">
					<?php echo JText::_( 'Review' ); ?>:
				</label>
			</td>
			<td>
            <?php
				$editor =& JFactory::getEditor();
				echo $editor->display('review', $this->song->review, '550', '200', '60', '20', false);
			?>
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="file">
					<?php echo JText::_( 'Songwriters' ); ?>:
				</label>
			</td>
			<td>
<textarea name="songwriters" id="songwriters" rows="4" cols="40"><?php echo $this->song->songwriters;?></textarea>		
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="file">
					<?php echo JText::_( 'Chords' ); ?>:
				</label>
			</td>
			<td>
<textarea name="chords" id="chords" rows="20" cols="100"><?php echo $this->song->chords;?></textarea>		
			</td>
		</tr>
        <tr>
			<td width="100" align="right" class="key">
				<label for="lyrics">
					<?php echo JText::_( 'Lyrics' ); ?>:
				</label>
			</td>
			<td>
            <?php
				echo $editor->display('lyrics', $this->song->lyrics, '550', '400', '60', '20', false);
			?>
			</td>
		</tr>
            
	</table>
	
	</fieldset>
</div>

<div class="clr"></div>

<input type="hidden" name="album_id" value="<?php echo $this->song->album_id;?>" />

<input type="hidden" name="option" value="com_muscol" />
<input type="hidden" name="id" value="<?php echo $this->song->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="controller" value="song" />
</form>
